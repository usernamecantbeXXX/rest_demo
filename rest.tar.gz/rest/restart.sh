#!/bin/sh
./stop.sh
./start.sh